/**
 * Assets are folder located in the /lib/assets folder
 */









;
